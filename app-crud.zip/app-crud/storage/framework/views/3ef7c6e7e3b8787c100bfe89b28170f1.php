<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Edit a Product</h1>
    <div>
        <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <?php endif; ?>
    </div>
    <form method="post" action="<?php echo e(route('product.update',['product' => $product])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div>
            <label>Name: </label>
            <input type="text" name="name" placeholder="Enter Name" value="<?php echo e($product->name); ?>"/>
        </div><br>
        <div>
            <label>Qty: </label>
            <input type="text" name="qty" placeholder="Enter Quantity" value="<?php echo e($product->qty); ?>"/>
        </div><br>
        <div>
            <label>Price: </label>
            <input type="text" name="price" placeholder="Enter Price" value="<?php echo e($product->price); ?>"/>
        </div><br>
        <div>
            <label>Description: </label>
            <input type="text" name="description" placeholder="Enter Description" value="<?php echo e($product->description); ?>"/>
        </div><br>
        <div>
            <input type="submit" value="Update"/>
        </div>

    </form>
</body>
</html><?php /**PATH C:\wamp64\www\app-crud\resources\views/products/edit.blade.php ENDPATH**/ ?>